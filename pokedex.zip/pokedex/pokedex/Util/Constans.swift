//
//  Constans.swift
//  pokedex
//
//  Created by Maury on 18/05/22.
//

import Foundation
import Alamofire

let URL_BASE = "https://pokeapi.co/api/v2/"
let URL_POKEMON = "pokemon/"
let URL_Description = "pokemon-species/"

typealias DownloadComplete = () -> ()
