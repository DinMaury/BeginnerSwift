//
//  ViewController.swift
//  htchhkr - development
//
//  Created by Maury on 20/06/22.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var actionButton: RoundedShadowButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
    }


    @IBAction func actionButtonPressed(_ sender: Any) {
        
        actionButton.animateButton(shouldLoad: true, withMessage: nil)
    }
}

